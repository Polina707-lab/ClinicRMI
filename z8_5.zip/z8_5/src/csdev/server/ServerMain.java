package csdev.server;

import java.io.*;
import java.net.*;
import java.util.*;
import csdev.*;

public class ServerMain {

    public static Map<String, Appointment> schedule = new HashMap<>();
    private static final String FILE_NAME = "data/appointments.dat";

    public static void main(String[] args) {
        loadSchedule();

        try (ServerSocket server = new ServerSocket(Protocol.PORT)) {
            System.err.println("Dental appointment server started on port " + Protocol.PORT);
            System.err.println("Press Ctrl+C to stop.");

            while (true) {
                Socket socket = server.accept();
                System.err.println("Client connected: " + socket.getInetAddress().getHostName());
                new ServerThread(socket).start();
            }

        } catch (IOException e) {
            System.err.println("Server error: " + e);
        } finally {
            saveSchedule();
        }
    }

    
    public static synchronized boolean isSlotFree(String datetime) {
        return !schedule.containsKey(datetime);
    }

    
    public static synchronized void addAppointment(Appointment a) {
        schedule.put(a.datetime, a);
        saveSchedule();
    }

    
    public static synchronized String[] getFreeSlots() {
        String[] days = {"Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"};
        List<String> allSlots = new ArrayList<>();

        for (String d : days) {
            for (int h = 9; h <= 16; h += 2) {
                String slot = String.format("%s %02d:00", d, h);
                if (!schedule.containsKey(slot)) {
                    allSlots.add(slot);
                }
            }
        }
        return allSlots.toArray(new String[0]);
    }

   
    public static synchronized String[] getAllAppointments() {
        return schedule.values().stream()
                .map(Appointment::toString)
                .toArray(String[]::new);
    }

    
    public static synchronized void saveSchedule() {
        try {
            File f = new File(FILE_NAME);
            f.getParentFile().mkdirs();
            try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(f))) {
                oos.writeObject(schedule);
            }
            System.err.println("Schedule saved (" + schedule.size() + " records).");
        } catch (IOException e) {
            System.err.println("Error saving schedule: " + e.getMessage());
        }
    }

    
    @SuppressWarnings("unchecked")
    public static synchronized void loadSchedule() {
        File f = new File(FILE_NAME);
        if (!f.exists()) {
            System.err.println("Schedule file not found, creating new one.");
            return;
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(f))) {
            schedule = (Map<String, Appointment>) ois.readObject();
            System.err.println("Schedule loaded (" + schedule.size() + " records).");
        } catch (Exception e) {
            System.err.println("Error loading schedule: " + e.getMessage());
            schedule = new HashMap<>();
        }
    }
}
